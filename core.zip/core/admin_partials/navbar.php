<?php
// ============================================================
// admin/partials/navbar.php
// ============================================================
$admin   = current_admin();
$current = basename($_SERVER['PHP_SELF']);
?>
<style>
  /* Theme-matched Navbar Styles */
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;1,600&family=Montserrat:wght@400;500;600;700&display=swap');

  .admin-nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #ffffff;
    padding: 16px 32px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    border-bottom: 3px solid #cc0000;
    font-family: 'Montserrat', sans-serif;
  }
  .nav-brand {
    font-family: 'Playfair Display', serif;
    font-size: 1.4rem;
    font-weight: 700;
    color: #cc0000;
    letter-spacing: 0.5px;
  }
  .nav-brand span {
    color: #222;
  }
  .nav-links {
    display: flex;
    gap: 24px;
  }
  .nav-links a {
    text-decoration: none;
    color: #666666;
    font-weight: 500;
    font-size: 0.95rem;
    transition: color 0.2s ease;
    padding: 6px 0;
  }
  .nav-links a:hover {
    color: #cc0000;
  }
  .nav-links a.active {
    color: #cc0000;
    font-weight: 600;
    border-bottom: 2px solid #cc0000;
  }
  .nav-user {
    display: flex;
    align-items: center;
    gap: 16px;
    font-size: 0.9rem;
    color: #444;
  }
  .role-badge {
    background: #ffe5e5;
    color: #cc0000;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .nav-logout {
    color: #666;
    text-decoration: none;
    font-weight: 600;
    border-left: 1px solid #eee;
    padding-left: 16px;
    transition: color 0.2s ease;
  }
  .nav-logout:hover {
    color: #cc0000;
  }
</style>

<nav class="admin-nav">
  <div class="nav-brand">DMA <span>Admin</span></div>
  
  <div class="nav-links">
    <a href="/admin/dashboard.php" class="<?= $current==='dashboard.php'?'active':'' ?>">📋 Registrations</a>
    
    <?php if ($admin['role'] === 'superadmin'): ?>
    <a href="/admin/users.php"     class="<?= $current==='users.php'    ?'active':'' ?>">👥 Users</a>
    <a href="/admin/history.php"   class="<?= $current==='history.php'  ?'active':'' ?>">🕒 Activity History</a>
    <?php endif; ?>
    
    <?php if ($admin['role'] !== 'viewer'): ?>
    <a href="/admin/settings.php"  class="<?= $current==='settings.php' ?'active':'' ?>">⚙️ Settings</a>
    <?php endif; ?>
  </div>

  <div class="nav-user">
    <span>👤 <?= htmlspecialchars($admin['full_name']) ?></span>
    <span class="role-badge"><?= $admin['role'] ?></span>
    <a href="/admin/logout.php" class="nav-logout">Logout</a>
  </div>
</nav>