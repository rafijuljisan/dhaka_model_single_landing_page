<?php
// ============================================================
// index.php — Dhaka Model Agency | Grooming Registration
// ============================================================
require_once __DIR__ . '/../core/includes/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Pull backend config
$pixel_id       = get_setting('fb_pixel_id', '');
$campaign_name  = get_setting('campaign_name', 'DMA Grooming Campaign');
$is_active      = get_setting('campaign_active', '1') === '1';
$contact_phone  = get_setting('contact_phone', '');
$contact_email  = get_setting('contact_email', '');

// DB stats for social proof counter
$db    = db();
$count = (int)$db->query("SELECT COUNT(*) AS c FROM registrations")->fetch_assoc()['c'];
$max   = (int)get_setting('max_registrations', '500');
$slots = max(0, $max - $count);

// Flash errors from submit.php
$form_errors = $_SESSION['form_errors'] ?? [];
$form_old    = $_SESSION['form_old']    ?? [];
unset($_SESSION['form_errors'], $_SESSION['form_old']);

// Query param errors
$query_error = $_GET['error'] ?? '';

// YouTube video ID — update this
$youtube_id = 'dQw4w9WgXcQ'; // ← Replace with your video ID

// Curriculum items
$curriculum = [
  ['icon'=>'walk',    'title'=>'রানওয়ে ওয়াক',        'desc'=>'পেশাদার ক্যাটওয়াক টেকনিক ও পোশচার ট্রেনিং'],
  ['icon'=>'camera',  'title'=>'ক্যামেরা পোজিং',       'desc'=>'ফটোশুট ও ভিডিও শ্যুটের জন্য পোজিং মাস্টারক্লাস'],
  ['icon'=>'face',    'title'=>'স্কিন কেয়ার',          'desc'=>'ত্বকের যত্ন, মেকআপ বেসিক ও ব্যক্তিগত গ্রুমিং'],
  ['icon'=>'body',    'title'=>'ফিটনেস ও ডায়েট',       'desc'=>'মডেলিংয়ের জন্য প্রয়োজনীয় শারীরিক সুস্থতা'],
  ['icon'=>'style',   'title'=>'স্টাইলিং ও ফ্যাশন',    'desc'=>'পোশাক নির্বাচন, কালার থিওরি ও ব্যক্তিত্ব বিকাশ'],
  ['icon'=>'network', 'title'=>'ইন্ডাস্ট্রি নেটওয়ার্ক', 'desc'=>'ব্র্যান্ড, ফটোগ্রাফার ও এজেন্সির সাথে সংযোগ'],
];

// Mentors (Reduced to 1 as requested)
$mentors = [
  ['name'=>'রাফিয়া হোসেন', 'title'=>'প্রধান গ্রুমিং ও স্টাইলিং মেন্টর', 'exp'=>'১০+ বছরের অভিজ্ঞতা', 'img'=>'assets/mentor-1.jpg'],
];

// FAQ
$faqs = [
  ['q'=>'আগে কোনো অভিজ্ঞতা দরকার আছে কি?',
   'a'=>'না, একদমই না! এই প্রোগ্রামটি সম্পূর্ণ নতুনদের জন্যও ডিজাইন করা হয়েছে। আমরা একদম শুরু থেকে সব শেখাই।'],
  ['q'=>'গ্রুমিং সেশনে কী পরে আসতে হবে?',
   'a'=>'আরামদায়ক, ফিটিং পোশাক পরে আসুন। নিজের পছন্দের ২টি আউটফিট সঙ্গে আনতে পারেন স্টাইলিং সেশনের জন্য।'],
  ['q'=>'রেজিস্ট্রেশন ফি কি ফেরতযোগ্য?',
   'a'=>'সিট কনফার্ম হওয়ার ৪৮ ঘণ্টার মধ্যে বাতিল করলে সম্পূর্ণ ফি ফেরত পাবেন। এর পরে বাতিল করলে ৫০% ফেরত দেওয়া হবে।'],
  ['q'=>'প্রোগ্রামটি কতদিন চলবে?',
   'a'=>'মোট ৬ সপ্তাহের প্রোগ্রাম। প্রতি সপ্তাহান্তে (শুক্র ও শনি) ঢাকায় আমাদের স্টুডিওতে ক্লাস অনুষ্ঠিত হবে।'],
];

$districts = ['ঢাকা','চট্টগ্রাম','সিলেট','রাজশাহী','খুলনা','বরিশাল','রংপুর','ময়মনসিংহ',
              'গাজীপুর','নারায়ণগঞ্জ','কুমিল্লা','সাভার','টঙ্গী','অন্যান্য'];
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="ঢাকা মডেল এজেন্সি গ্রুমিং প্রোগ্রাম ২০২৬ — পেশাদার মডেলিং ক্যারিয়ারের সঠিক শুরু">
<meta property="og:title" content="ঢাকা মডেল এজেন্সি গ্রুমিং প্রোগ্রাম">
<meta property="og:description" content="আপনার মডেলিং ক্যারিয়ার শুরু হোক সঠিক গ্রুমিং দিয়ে। সীমিত আসন — এখনই রেজিস্ট্রেশন করুন।">
<title>গ্রুমিং প্রোগ্রাম — ঢাকা মডেল এজেন্সি</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&family=Noto+Serif+Bengali:wght@400;600;700&display=swap" rel="stylesheet">

<?php if (!empty($pixel_id)): ?>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?= $pixel_id ?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=<?= $pixel_id ?>&ev=PageView&noscript=1"/></noscript>
<?php endif; ?>

<style>
/* ═══════════════════════════════════════════════════════════
   DESIGN TOKENS (Light/Red Theme)
═══════════════════════════════════════════════════════════ */
:root {
  --primary:      #cc0000;
  --primary-dark: #a30000;
  --primary-light:#ffe5e5;
  --bg-main:      #ffffff;
  --bg-alt:       #f9f9fa;
  --text-dark:    #1a1a1a;
  --text-muted:   #666666;
  --border:       #e5e7eb;
  --radius:       8px;
  --radius-lg:    16px;

  --font-display: 'Noto Serif Bengali', serif;
  --font-body:    'Noto Sans Bengali', sans-serif;

  --section-pad: clamp(64px, 10vw, 120px);
  --ease:        cubic-bezier(0.16, 1, 0.3, 1);
  --shadow-sm:   0 4px 6px -1px rgba(0, 0, 0, 0.05);
  --shadow-md:   0 10px 30px rgba(0, 0, 0, 0.08);
}

/* ═══════════════════════════════════════════════════════════
   RESET & BASE
═══════════════════════════════════════════════════════════ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; font-size: 16px; }
body {
  background: var(--bg-main);
  color: var(--text-dark);
  font-family: var(--font-body);
  font-weight: 400;
  line-height: 1.7;
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}
img { max-width: 100%; display: block; }
a { color: inherit; text-decoration: none; }
button, input, select, textarea { font-family: inherit; }

/* ── Scroll animations ── */
.reveal {
  opacity: 0;
  transform: translateY(32px);
  transition: opacity 0.8s var(--ease), transform 0.8s var(--ease);
}
.reveal.visible {
  opacity: 1;
  transform: translateY(0);
}
.reveal-delay-1 { transition-delay: 0.1s; }
.reveal-delay-2 { transition-delay: 0.2s; }

/* ═══════════════════════════════════════════════════════════
   NAVIGATION
═══════════════════════════════════════════════════════════ */
.nav {
  position: fixed; top: 0; left: 0; right: 0;
  z-index: 500;
  max-width: 1140px; /* Added */
  margin: 0 auto;    /* Added */
  padding: 20px 40px;
  display: flex; align-items: center; justify-content: space-between;
  transition: all 0.4s var(--ease);
}
.nav.scrolled {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  padding: 14px 40px;
  border-bottom: 1px solid var(--border);
  box-shadow: var(--shadow-sm);
  border-bottom-left-radius: var(--radius);  /* Keeps corners smooth */
  border-bottom-right-radius: var(--radius); /* Keeps corners smooth */
}
.nav-logo {
  display: flex;
  align-items: center;
  gap: 12px; /* লোগো এবং নামের মাঝখানের স্পেস */
  text-decoration: none;
}

.nav-logo img {
  height: 40px; 
  width: auto;
  transition: transform 0.3s var(--ease);
}

.nav-logo:hover img {
  transform: scale(1.05);
}

.nav-logo .logo-text { 
  font-family: var(--font-display);
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--primary);
  line-height: 1;
  white-space: nowrap; /* নামটিকে এক লাইনে রাখবে */
}

/* Optional: মোবাইলের ছোট স্ক্রিনে জায়গা বাঁচাতে চাইলে নামটা লুকিয়ে শুধু লোগো দেখাতে পারেন */
@media (max-width: 480px) {
  .nav-logo .logo-text {
    display: none; /* সাইজ একটু ছোট হবে */
  }
}

/* Optional: Fallback styles if the image fails to load */
.nav-logo span { 
  font-family: var(--font-display);
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--primary);
  margin-left: 8px; /* Space between logo icon and text if you keep both */
}
.nav-cta {
  background: var(--primary);
  color: white;
  padding: 10px 24px;
  border-radius: var(--radius);
  font-weight: 600;
  font-size: 0.9rem;
  transition: all 0.3s var(--ease);
}
.nav-cta:hover { background: var(--primary-dark); transform: translateY(-1px); }

/* ═══════════════════════════════════════════════════════════
   HERO
═══════════════════════════════════════════════════════════ */
.hero {
  min-height: 100svh;
  display: flex; align-items: center; justify-content: center;
  position: relative;
  overflow: hidden;
  padding: 140px 40px 80px;
  background: radial-gradient(circle at top right, var(--primary-light), transparent 50%),
              radial-gradient(circle at bottom left, #f3f4f6, transparent 50%);
}

.hero-content {
  position: relative; z-index: 2;
  max-width: 800px;
  text-align: center;
}

.hero-eyebrow {
  display: inline-flex; align-items: center; gap: 10px;
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--primary);
  text-transform: uppercase;
  margin-bottom: 24px;
  opacity: 0;
  animation: fadeUp 0.8s 0.2s var(--ease) forwards;
}
.hero-eyebrow::before,
.hero-eyebrow::after {
  content: ''; width: 40px; height: 2px; background: var(--primary); opacity: 0.3;
}

.hero-headline {
  font-family: var(--font-display);
  font-size: clamp(2.4rem, 6vw, 4.5rem);
  font-weight: 700;
  line-height: 1.15;
  color: var(--text-dark);
  margin-bottom: 24px;
  opacity: 0;
  animation: fadeUp 0.9s 0.4s var(--ease) forwards;
}
.hero-headline em {
  font-style: normal;
  color: var(--primary);
}

.hero-sub {
  font-size: clamp(1rem, 2.5vw, 1.15rem);
  color: var(--text-muted);
  max-width: 600px;
  margin: 0 auto 40px;
  opacity: 0;
  animation: fadeUp 0.9s 0.6s var(--ease) forwards;
}

.hero-actions {
  display: flex; align-items: center; justify-content: center; gap: 16px;
  flex-wrap: wrap;
  opacity: 0;
  animation: fadeUp 0.9s 0.8s var(--ease) forwards;
}

.btn-primary {
  display: inline-flex; align-items: center; gap: 10px;
  background: var(--primary);
  color: white;
  padding: 16px 36px;
  border-radius: var(--radius);
  font-weight: 600;
  font-size: 1rem;
  transition: all 0.3s var(--ease);
  border: none; cursor: pointer;
  box-shadow: 0 4px 15px rgba(204, 0, 0, 0.2);
}
.btn-primary:hover { 
  background: var(--primary-dark); 
  transform: translateY(-2px); 
  box-shadow: 0 8px 25px rgba(204, 0, 0, 0.3); 
}

.btn-ghost {
  display: inline-flex; align-items: center; gap: 8px;
  color: var(--text-dark);
  padding: 16px 28px;
  border: 1.5px solid var(--border);
  border-radius: var(--radius);
  font-weight: 600;
  font-size: 1rem;
  transition: all 0.3s var(--ease);
  background: white;
  cursor: pointer;
}
.btn-ghost:hover { border-color: var(--primary); color: var(--primary); }

/* Slots indicator */
.hero-slots {
  margin-top: 30px;
  display: flex; align-items: center; justify-content: center; gap: 12px;
  opacity: 0;
  animation: fadeUp 0.9s 1s var(--ease) forwards;
}
.slots-bar-wrap {
  width: 160px; height: 6px;
  background: var(--border);
  border-radius: 4px; overflow: hidden;
}
.slots-bar {
  height: 100%;
  background: var(--primary);
  border-radius: 4px;
  transition: width 1.5s 1.5s var(--ease);
}
.slots-text {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--text-muted);
}
.slots-text strong { color: var(--primary); }

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(24px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ═══════════════════════════════════════════════════════════
   SECTION COMMONS
═══════════════════════════════════════════════════════════ */
.section { padding: var(--section-pad) 40px; }
.section-alt { background: var(--bg-alt); }
.container { max-width: 1140px; margin: 0 auto; }

.section-label {
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--primary);
  text-transform: uppercase;
  margin-bottom: 12px;
  display: flex; align-items: center; gap: 12px;
}
.section-label::before {
  content: ''; width: 32px; height: 2px; background: var(--primary);
}

.section-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4.5vw, 3rem);
  font-weight: 700;
  line-height: 1.2;
  color: var(--text-dark);
  margin-bottom: 16px;
}

.section-subtitle {
  font-size: 1.1rem;
  color: var(--text-muted);
  max-width: 560px;
  margin-bottom: 48px;
}

/* Red divider line */
.primary-line {
  width: 64px; height: 3px;
  background: var(--primary);
  margin: 24px 0;
  border-radius: 2px;
}

/* ═══════════════════════════════════════════════════════════
   VIDEO SECTION
═══════════════════════════════════════════════════════════ */
.video-section {
  padding: var(--section-pad) 40px;
  background: var(--text-dark);
}
.video-section .section-label { color: var(--primary-light); }
.video-section .section-label::before { background: var(--primary-light); }
.video-section .section-title { color: white; }
.video-section .section-subtitle { color: #aaaaaa; }

.video-wrap {
  max-width: 840px; margin: 0 auto;
  border-radius: var(--radius-lg);
  overflow: hidden;
  box-shadow: 0 30px 60px rgba(0,0,0,0.4);
  position: relative;
}

.yt-facade {
  aspect-ratio: 16/9;
  position: relative;
  cursor: pointer;
  background: #000;
  display: flex; align-items: center; justify-content: center;
}
.yt-facade img {
  position: absolute; inset: 0; width: 100%; height: 100%;
  object-fit: cover; opacity: 0.8; transition: opacity 0.3s;
}
.yt-facade:hover img { opacity: 0.95; }

.yt-play-btn {
  position: relative; z-index: 2;
  width: 80px; height: 80px;
  background: var(--primary);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  transition: transform 0.3s var(--ease);
  box-shadow: 0 0 20px rgba(204, 0, 0, 0.5);
}
.yt-facade:hover .yt-play-btn { transform: scale(1.1); background: var(--primary-dark); }
.yt-play-btn svg { fill: white; margin-left: 6px; }
.yt-iframe { display: none; }
.yt-iframe iframe { width: 100%; aspect-ratio: 16/9; border: none; display: block; }

.video-caption { text-align: center; margin-top: 24px; font-size: 0.95rem; color: #888888; }

/* ═══════════════════════════════════════════════════════════
   CURRICULUM GRID
═══════════════════════════════════════════════════════════ */
.curriculum-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.curriculum-card {
  background: var(--bg-main);
  padding: 40px 32px;
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  position: relative;
  transition: transform 0.3s var(--ease), box-shadow 0.3s var(--ease);
}
.curriculum-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-md);
  border-color: rgba(204,0,0,0.2);
}

.curriculum-icon {
  width: 56px; height: 56px;
  background: var(--primary-light);
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 24px;
  color: var(--primary);
}
.curriculum-icon svg { width: 28px; height: 28px; stroke: currentColor; fill: none; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; }

.curriculum-title {
  font-family: var(--font-display);
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--text-dark);
  margin-bottom: 12px;
}
.curriculum-desc {
  font-size: 0.95rem;
  color: var(--text-muted);
  line-height: 1.6;
}
.curriculum-num {
  position: absolute; top: 24px; right: 24px;
  font-size: 2rem;
  font-weight: 700;
  color: var(--border);
  line-height: 1;
}

/* ═══════════════════════════════════════════════════════════
   MENTORS (Centered Single Layout)
═══════════════════════════════════════════════════════════ */
.mentors-wrap {
  display: flex; justify-content: center; /* Center the single mentor */
}
.mentor-card {
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  overflow: hidden;
  background: var(--bg-main);
  box-shadow: var(--shadow-sm);
  max-width: 400px;
  width: 100%;
}
.mentor-photo {
  aspect-ratio: 4/3;
  background: var(--bg-alt);
  overflow: hidden;
}
.mentor-photo img { width: 100%; height: 100%; object-fit: cover; object-position: top; }
.mentor-photo-placeholder {
  width: 100%; height: 100%;
  display: flex; align-items: center; justify-content: center;
  font-size: 4rem; color: var(--border);
}
.mentor-info { padding: 32px; text-align: center; }
.mentor-name {
  font-family: var(--font-display);
  font-size: 1.8rem;
  font-weight: 700;
  color: var(--text-dark);
  margin-bottom: 8px;
}
.mentor-title {
  font-size: 0.95rem;
  font-weight: 600;
  color: var(--primary);
  margin-bottom: 16px;
}
.mentor-exp {
  display: inline-flex; align-items: center; gap: 8px;
  background: var(--bg-alt);
  border-radius: 999px;
  padding: 6px 16px;
  font-size: 0.9rem;
  color: var(--text-muted);
}

/* ═══════════════════════════════════════════════════════════
   STATS BAR
═══════════════════════════════════════════════════════════ */
.stats-bar {
  background: var(--primary);
  padding: 48px 40px;
  color: white;
}
.stats-bar-inner {
  max-width: 1140px; margin: 0 auto;
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  text-align: center;
}
.stat-num  { font-family: var(--font-display); font-size: clamp(2.5rem, 4vw, 3.5rem); font-weight: 700; line-height: 1; margin-bottom: 8px;}
.stat-lbl  { font-size: 1rem; font-weight: 500; opacity: 0.9; }

/* ═══════════════════════════════════════════════════════════
   GALLERY
═══════════════════════════════════════════════════════════ */
.gallery-grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  grid-auto-rows: 240px;
  gap: 16px;
}
.gallery-item {
  background: var(--bg-alt);
  border-radius: var(--radius);
  overflow: hidden;
}
.gallery-item:nth-child(1) { grid-column: span 5; grid-row: span 2; }
.gallery-item:nth-child(2) { grid-column: span 4; grid-row: span 1; }
.gallery-item:nth-child(3) { grid-column: span 3; grid-row: span 1; }
.gallery-item:nth-child(4) { grid-column: span 4; grid-row: span 1; }
.gallery-item:nth-child(5) { grid-column: span 3; grid-row: span 1; }
.gallery-item:nth-child(6) { grid-column: span 3; grid-row: span 2; }
.gallery-item:nth-child(7) { grid-column: span 4; grid-row: span 1; }
.gallery-item:nth-child(8) { grid-column: span 5; grid-row: span 1; }

.gallery-item img {
  width: 100%; height: 100%;
  object-fit: cover;
}
.gallery-placeholder {
  width: 100%; height: 100%;
  display: flex; align-items: center; justify-content: center;
  background: var(--border);
  color: var(--text-muted);
}
.gallery-placeholder-text {
  font-size: 0.8rem; text-align: center; padding: 20px;
}

/* ═══════════════════════════════════════════════════════════
   REGISTRATION FORM
═══════════════════════════════════════════════════════════ */
.form-section {
  padding: var(--section-pad) 40px;
  background: var(--bg-alt);
}
.form-layout {
  display: grid;
  grid-template-columns: 5fr 7fr;
  gap: 64px;
  align-items: start;
}
.form-pitch { position: sticky; top: 120px; }

.form-benefits {
  list-style: none;
  display: flex; flex-direction: column; gap: 16px;
  margin-top: 32px;
}
.form-benefits li {
  display: flex; align-items: flex-start; gap: 14px;
  font-size: 1rem; color: var(--text-dark); font-weight: 500;
}
.form-benefits li::before {
  content: '✓';
  flex-shrink: 0;
  width: 24px; height: 24px;
  background: var(--primary-light);
  color: var(--primary);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 0.8rem; font-weight: bold;
}

.price-box {
  margin-top: 48px;
  padding: 32px;
  background: white;
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-md);
  border-top: 4px solid var(--primary);
}
.price-label { font-size: 1rem; color: var(--text-muted); font-weight: 600; }
.price-amount {
  font-family: var(--font-display);
  font-size: 3.5rem; font-weight: 700;
  color: var(--primary);
  line-height: 1;
  margin: 8px 0;
}
.price-note { font-size: 0.9rem; color: var(--text-muted); }

/* Form card */
.form-card {
  background: white;
  border-radius: var(--radius-lg);
  padding: 48px;
  box-shadow: var(--shadow-md);
}
.form-card-title {
  font-family: var(--font-display);
  font-size: 2rem; font-weight: 700;
  color: var(--text-dark);
  margin-bottom: 8px;
}
.form-card-sub { font-size: 0.95rem; color: var(--text-muted); margin-bottom: 32px; }

/* Form alerts */
.form-alert {
  padding: 16px 20px;
  border-radius: var(--radius);
  margin-bottom: 24px;
  font-size: 0.95rem;
}
.form-alert-error { background: #fee2e2; border: 1px solid #fca5a5; color: #991b1b; }
.form-alert-error ul { padding-left: 20px; margin-top: 8px; }

/* Form fields */
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.form-group { margin-bottom: 24px; }
.form-label {
  display: block;
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--text-dark);
  margin-bottom: 8px;
}
.form-label span { color: var(--primary); }

.form-input, .form-select, .form-textarea {
  width: 100%;
  background: var(--bg-alt);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  color: var(--text-dark);
  font-size: 1rem;
  padding: 14px 16px;
  transition: border-color 0.2s, box-shadow 0.2s;
  outline: none;
}
.form-input:focus, .form-select:focus, .form-textarea:focus {
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(204, 0, 0, 0.1);
  background: white;
}
.form-input.invalid, .form-select.invalid { border-color: #ef4444; }

.form-hint { font-size: 0.8rem; color: var(--text-muted); margin-top: 6px; }
.form-error-text { font-size: 0.8rem; color: #ef4444; margin-top: 6px; display: none; }
.form-error-text.show { display: block; }

/* File upload */
.upload-zone {
  border: 2px dashed var(--border);
  border-radius: var(--radius);
  padding: 32px 20px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
  background: var(--bg-alt);
  position: relative;
}
.upload-zone:hover { border-color: var(--primary); background: var(--primary-light); }
.upload-zone input[type=file] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
.upload-icon { font-size: 2.5rem; margin-bottom: 12px; }
.upload-text { font-size: 0.95rem; color: var(--text-muted); }
.upload-text strong { color: var(--primary); }
.upload-preview { display: none; margin-top: 12px; font-size: 0.9rem; color: var(--primary); font-weight: 600; justify-content: center;}
.upload-preview.show { display: flex; }

.form-submit {
  width: 100%;
  background: var(--primary);
  color: white;
  border: none;
  padding: 20px;
  border-radius: var(--radius);
  font-size: 1.1rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s var(--ease);
  margin-top: 16px;
}
.form-submit:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 10px 20px rgba(204,0,0,0.2); }

/* ═══════════════════════════════════════════════════════════
   FAQ
═══════════════════════════════════════════════════════════ */
.faq-list { display: flex; flex-direction: column; gap: 16px; max-width: 800px; margin: 0 auto; }
.faq-item {
  border: 1px solid var(--border);
  border-radius: var(--radius);
  background: white;
  overflow: hidden;
  transition: border-color 0.3s, box-shadow 0.3s;
}
.faq-item.open { border-color: var(--primary); box-shadow: var(--shadow-sm); }
.faq-q {
  width: 100%;
  display: flex; align-items: center; justify-content: space-between;
  padding: 24px;
  background: none; border: none; cursor: pointer;
  color: var(--text-dark);
  font-size: 1.1rem;
  font-weight: 600;
  text-align: left;
  gap: 16px;
}
.faq-item.open .faq-q { color: var(--primary); }
.faq-icon {
  flex-shrink: 0; width: 32px; height: 32px;
  background: var(--bg-alt);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: var(--text-muted);
  font-size: 1.2rem;
  transition: all 0.3s var(--ease);
}
.faq-item.open .faq-icon { transform: rotate(45deg); background: var(--primary-light); color: var(--primary); }
.faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s var(--ease); }
.faq-item.open .faq-a { max-height: 300px; }
.faq-a-inner { padding: 0 24px 24px; font-size: 1rem; color: var(--text-muted); }

/* ═══════════════════════════════════════════════════════════
   FOOTER
═══════════════════════════════════════════════════════════ */
.footer {
  background: var(--text-dark);
  color: white;
  padding: 60px 40px;
  text-align: center;
}
.footer-logo {
  font-family: var(--font-display);
  font-size: 1.8rem; font-weight: 700;
  color: white;
  margin-bottom: 16px;
}
.footer-contact { font-size: 1rem; color: #aaaaaa; margin-bottom: 24px; }
.footer-contact a { color: white; margin: 0 8px;}
.footer-copy { font-size: 0.9rem; color: #666666; }

/* ═══════════════════════════════════════════════════════════
   STICKY BOTTOM BAR
═══════════════════════════════════════════════════════════ */
.sticky-bar {
  position: fixed;
  bottom: 0; left: 0; right: 0;
  z-index: 400;
  max-width: 1140px; /* Added */
  margin: 0 auto;    /* Added */
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-top: 1px solid var(--border);
  border-left: 1px solid var(--border); /* Added for boxed look */
  border-right: 1px solid var(--border); /* Added for boxed look */
  border-top-left-radius: var(--radius);  /* Smooth top corners */
  border-top-right-radius: var(--radius); /* Smooth top corners */
  box-shadow: 0 -10px 30px rgba(0,0,0,0.05);
  padding: 16px 24px;
  display: flex; align-items: center; justify-content: space-between;
  gap: 20px;
  transform: translateY(100%);
  transition: transform 0.4s var(--ease);
}
.sticky-bar.visible { transform: translateY(0); }
.sticky-bar.hidden-near-form { transform: translateY(100%); }
.sticky-price-label { font-size: 0.8rem; color: var(--text-muted); font-weight: 600; }
.sticky-price {
  font-family: var(--font-display);
  font-size: 1.8rem; font-weight: 700;
  color: var(--primary);
  line-height: 1;
}
.sticky-cta {
  background: var(--primary);
  color: white;
  border: none; cursor: pointer;
  padding: 16px 36px;
  border-radius: var(--radius);
  font-size: 1rem;
  font-weight: 700;
  transition: all 0.3s var(--ease);
}
.sticky-cta:hover { background: var(--primary-dark); }
.sticky-slots-text { font-size: 0.85rem; color: var(--text-muted); margin-top: 4px; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
  .curriculum-grid { grid-template-columns: repeat(2, 1fr); }
  .form-layout { grid-template-columns: 1fr; gap: 48px; }
  .form-pitch { position: static; text-align: center; }
  .form-benefits { align-items: center; }
  .gallery-grid { grid-template-columns: 1fr 1fr 1fr; grid-auto-rows: 200px; }
  .gallery-item { grid-column: span 1 !important; grid-row: span 1 !important; }
}
@media (max-width: 768px) {
  :root { --section-pad: 80px; }
  .section, .video-section, .form-section { padding: 60px 20px; }
  .nav { padding: 16px 20px; }
  .hero { padding: 120px 20px 80px; }
  .stats-bar { padding: 40px 20px; }
  .stats-bar-inner { grid-template-columns: repeat(2, 1fr); gap: 32px; }
  .curriculum-grid { grid-template-columns: 1fr; }
  .form-row { grid-template-columns: 1fr; }
  .form-card { padding: 32px 20px; }
  .gallery-grid { grid-template-columns: 1fr 1fr; grid-auto-rows: 160px; }
  .gallery-item:nth-child(1) { grid-column: span 2; }
  .sticky-bar { padding: 12px 16px; flex-direction: column; text-align: center; gap: 12px;}
  .sticky-cta { width: 100%; padding: 14px; }
}
@media (max-width: 480px) {
  .hero-headline { font-size: 2.2rem; }
  .btn-primary, .btn-ghost { width: 100%; justify-content: center; }
  .gallery-grid { grid-template-columns: 1fr; }
  .gallery-item { grid-column: span 1 !important; grid-row: span 1 !important; }
}
</style>
</head>
<body>

<nav class="nav" id="navbar">
  <a href="/" class="nav-logo">
    <img src="/assets/dma-logo.png" alt="Dhaka Model Agency Logo">
    <span class="logo-text">Dhaka Model Agency</span>
  </a>
  
  <?php if ($is_active): ?>
  <a href="#register" class="nav-cta">রেজিস্ট্রেশন করুন →</a>
  <?php endif; ?>
</nav>

<section class="hero" id="hero">
  <div class="hero-content">
    <div class="hero-eyebrow">ঢাকা মডেল এজেন্সি</div>
    <h1 class="hero-headline">
      আপনার মডেলিং ক্যারিয়ার<br>
      শুরু হোক <em>সঠিক গ্রুমিং</em> দিয়ে
    </h1>
    <p class="hero-sub">
      ৬ সপ্তাহের নিবিড় প্রফেশনাল গ্রুমিং প্রোগ্রাম।
      রানওয়ে থেকে ক্যামেরা — সব কিছু শিখুন শিল্পের সেরা মেন্টরদের কাছ থেকে।
    </p>
    <?php if ($is_active): ?>
    <div class="hero-actions">
      <a href="#register" class="btn-primary">
        <span>এখনই রেজিস্ট্রেশন করুন</span>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
      <a href="#video" class="btn-ghost">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
        ভিডিও দেখুন
      </a>
    </div>
    <?php else: ?>
    <p style="color:var(--primary);font-size:1.1rem;margin-top:20px;font-weight:600;">রেজিস্ট্রেশন বর্তমানে বন্ধ আছে।</p>
    <?php endif; ?>
  </div>
</section>

<div class="stats-bar reveal">
  <div class="stats-bar-inner">
    <div class="stat-item">
      <div class="stat-num">৬+</div>
      <div class="stat-lbl">সপ্তাহের প্রোগ্রাম</div>
    </div>
    <div class="stat-item">
      <div class="stat-num">৫০০+</div>
      <div class="stat-lbl">সফল মডেল</div>
    </div>
    <div class="stat-item">
      <div class="stat-num">১</div>
      <div class="stat-lbl">বিশেষজ্ঞ মেন্টর</div>
    </div>
    <div class="stat-item">
      <div class="stat-num">৬</div>
      <div class="stat-lbl">প্রফেশনাল মডিউল</div>
    </div>
  </div>
</div>

<section class="video-section" id="video">
  <div class="container">
    <div style="text-align:center; margin-bottom:48px;" class="reveal">
      <div class="section-label" style="justify-content:center;">আমাদের কাজ</div>
      <h2 class="section-title">দেখুন আমরা কী করি</h2>
      <p class="section-subtitle" style="margin:0 auto;">
        পেশাদার মডেলিং সেশনের পেছনের দৃশ্য, আমাদের ট্রেনিং পদ্ধতি এবং সফল মডেলদের যাত্রা।
      </p>
    </div>

    <div class="video-wrap reveal">
      <div class="yt-facade" id="ytFacade" data-ytid="<?= htmlspecialchars($youtube_id) ?>">
        <img src="https://i.ytimg.com/vi/<?= htmlspecialchars($youtube_id) ?>/maxresdefault.jpg"
             alt="DMA Grooming Program Video"
             loading="lazy"
             onerror="this.src='https://i.ytimg.com/vi/<?= htmlspecialchars($youtube_id) ?>/hqdefault.jpg'">
        <div class="yt-play-btn">
          <svg width="28" height="28" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        </div>
      </div>
      <div class="yt-iframe" id="ytIframe"></div>
    </div>
    <p class="video-caption reveal">আমাদের প্রোগ্রামের পেছনের দৃশ্য এবং সফল মডেলদের অভিজ্ঞতা</p>
  </div>
</section>

<section class="section section-alt" id="curriculum">
  <div class="container">
    <div class="reveal">
      <div class="section-label">প্রোগ্রামের বিষয়বস্তু</div>
      <h2 class="section-title">আপনি যা শিখবেন</h2>
      <p class="section-subtitle">প্রতিটি মডিউল ইন্ডাস্ট্রির বাস্তব চাহিদা অনুযায়ী ডিজাইন করা হয়েছে।</p>
    </div>
    <div class="curriculum-grid reveal">
      <?php foreach ($curriculum as $i => $item): ?>
      <div class="curriculum-card">
        <div class="curriculum-num"><?= str_pad($i+1, 2, '0', STR_PAD_LEFT) ?></div>
        <div class="curriculum-icon">
          <?= get_curriculum_icon($item['icon']) ?>
        </div>
        <h3 class="curriculum-title"><?= $item['title'] ?></h3>
        <p class="curriculum-desc"><?= $item['desc'] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section" id="mentors">
  <div class="container">
    <div class="reveal" style="text-align: center; display: flex; flex-direction: column; align-items: center;">
      <div class="section-label" style="justify-content: center;">আপনার মেন্টর</div>
      <h2 class="section-title">বিশেষজ্ঞ গাইডেন্স</h2>
      <p class="section-subtitle">বছরের পর বছরের বাস্তব অভিজ্ঞতা থেকে শিখুন।</p>
    </div>
    <div class="mentors-wrap reveal">
      <?php foreach ($mentors as $i => $m): ?>
      <div class="mentor-card">
        <div class="mentor-photo">
          <?php if (file_exists(__DIR__ . '/' . $m['img'])): ?>
          <img src="/<?= $m['img'] ?>" alt="<?= $m['name'] ?>" loading="lazy">
          <?php else: ?>
          <div class="mentor-photo-placeholder">👤</div>
          <?php endif; ?>
        </div>
        <div class="mentor-info">
          <h3 class="mentor-name"><?= $m['name'] ?></h3>
          <div class="mentor-title"><?= $m['title'] ?></div>
          <div class="mentor-exp">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <?= $m['exp'] ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section section-alt" id="gallery">
  <div class="container">
    <div style="text-align:center; margin-bottom:48px;" class="reveal">
      <div class="section-label" style="justify-content:center;">সফলতার গল্প</div>
      <h2 class="section-title">আমাদের মডেলরা</h2>
      <p class="section-subtitle" style="margin:0 auto;">
        আমাদের গ্রুমিং প্রোগ্রাম থেকে বেরিয়ে তারা এখন সফল ক্যারিয়ার গড়ে তুলেছেন।
      </p>
    </div>
    <div class="gallery-grid reveal">
      <?php for ($g = 1; $g <= 8; $g++): ?>
      <div class="gallery-item">
        <?php if (file_exists(__DIR__ . "/assets/gallery-{$g}.jpg")): ?>
        <img src="/assets/gallery-<?= $g ?>.jpg" alt="মডেল <?= $g ?>" loading="lazy">
        <?php else: ?>
        <div class="gallery-placeholder">
          <div class="gallery-placeholder-text">ছবি <?= $g ?><br>আপনার ছবি যোগ করুন<br>/assets/gallery-<?= $g ?>.jpg</div>
        </div>
        <?php endif; ?>
      </div>
      <?php endfor; ?>
    </div>
  </div>
</section>

<?php if ($is_active): ?>
<section class="form-section" id="register">
  <div class="container">
    <div class="form-layout">

      <div class="form-pitch reveal">
        <div class="section-label">রেজিস্ট্রেশন</div>
        <h2 class="section-title">আজই আপনার<br>সিট বুক করুন</h2>
        <div class="primary-line"></div>
        <p style="color:var(--text-muted);font-size:1.05rem;margin-bottom:0; line-height: 1.6;">
          সীমিত আসন। প্রতিটি সিটের জন্য ব্যক্তিগত মনোযোগ নিশ্চিত করা হয়।
          আপনার তথ্য পূরণ করুন — আমরা ৩ কার্যদিবসের মধ্যে যোগাযোগ করব।
        </p>

        <ul class="form-benefits">
          <li>পেশাদার মেন্টরের সরাসরি গাইডেন্স</li>
          <li>৬ সপ্তাহের স্ট্রাকচার্ড প্রোগ্রাম</li>
          <li>সার্টিফিকেট অফ কমপ্লিশন</li>
          <li>ইন্ডাস্ট্রি নেটওয়ার্কে প্রবেশাধিকার</li>
          <li>পোর্টফোলিও ফটোশুটের সুযোগ</li>
        </ul>

        <div class="price-box">
          <div class="price-label">কোর্স ফি</div>
          <div class="price-amount">৳৫,০০০</div>
          <div class="price-note">ভর্তির পর পেমেন্ট নিশ্চিত করতে হবে</div>
        </div>
      </div>

      <div class="reveal">
        <div class="form-card">
          <div class="form-card-title">রেজিস্ট্রেশন ফর্ম</div>
          <div class="form-card-sub">সমস্ত তথ্য সঠিকভাবে পূরণ করুন। <span style="color:var(--primary)">*</span> চিহ্নিত ঘর অবশ্যই পূরণ করতে হবে।</div>

          <?php if (!empty($form_errors) || $query_error === 'save_failed'): ?>
          <div class="form-alert form-alert-error">
            <strong>কিছু সমস্যা হয়েছে। অনুগ্রহ করে ঠিক করুন:</strong>
            <ul>
              <?php foreach ($form_errors as $err): ?>
              <li><?= htmlspecialchars($err) ?></li>
              <?php endforeach; ?>
              <?php if ($query_error === 'save_failed'): ?>
              <li>একটি সিস্টেম এরর হয়েছে। আবার চেষ্টা করুন।</li>
              <?php endif; ?>
            </ul>
          </div>
          <?php endif; ?>
          <?php if ($query_error === 'quota_full'): ?>
          <div class="form-alert" style="background:var(--primary-light);border:1px solid var(--primary);color:var(--primary-dark);">
            দুঃখিত — সমস্ত আসন পূর্ণ হয়ে গেছে।
          </div>
          <?php endif; ?>

          <form method="POST" action="/submit.php" enctype="multipart/form-data" id="regForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" for="full_name">পূর্ণ নাম <span>*</span></label>
                <input class="form-input" type="text" id="full_name" name="full_name"
                       placeholder="আপনার পুরো নাম"
                       value="<?= htmlspecialchars($form_old['full_name'] ?? '') ?>"
                       required minlength="3">
                <div class="form-error-text" id="err_full_name">নাম অন্তত ৩ অক্ষরের হতে হবে।</div>
              </div>
              <div class="form-group">
                <label class="form-label" for="phone">মোবাইল নম্বর <span>*</span></label>
                <input class="form-input" type="tel" id="phone" name="phone"
                       placeholder="01XXXXXXXXX"
                       value="<?= htmlspecialchars($form_old['phone'] ?? '') ?>"
                       required>
                <div class="form-hint">WhatsApp নম্বর দিন</div>
                <div class="form-error-text" id="err_phone">সঠিক বাংলাদেশি নম্বর দিন।</div>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="email">ইমেইল ঠিকানা</label>
              <input class="form-input" type="email" id="email" name="email"
                     placeholder="আপনার ইমেইল (ঐচ্ছিক)"
                     value="<?= htmlspecialchars($form_old['email'] ?? '') ?>">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" for="dob">জন্ম তারিখ <span>*</span></label>
                <input class="form-input" type="date" id="dob" name="dob"
                       value="<?= htmlspecialchars($form_old['dob'] ?? '') ?>"
                       required>
                <div class="form-hint">বয়স ১৬–৩৫ বছরের মধ্যে হতে হবে</div>
                <div class="form-error-text" id="err_dob">বৈধ জন্ম তারিখ দিন।</div>
              </div>
              <div class="form-group">
                <label class="form-label" for="gender">লিঙ্গ <span>*</span></label>
                <select class="form-select" id="gender" name="gender" required>
                  <option value="" disabled <?= empty($form_old['gender']) ? 'selected' : '' ?>>বেছে নিন</option>
                  <option value="female" <?= ($form_old['gender']??'')==='female'?'selected':'' ?>>মহিলা</option>
                  <option value="male"   <?= ($form_old['gender']??'')==='male'  ?'selected':'' ?>>পুরুষ</option>
                  <option value="other"  <?= ($form_old['gender']??'')==='other' ?'selected':'' ?>>অন্যান্য</option>
                </select>
                <div class="form-error-text" id="err_gender">লিঙ্গ বেছে নিন।</div>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" for="height_cm">উচ্চতা <span>*</span></label>
                <select class="form-select" id="height_cm" name="height_cm" required>
                  <option value="" disabled <?= empty($form_old['height_cm']) ? 'selected' : '' ?>>উচ্চতা বেছে নিন</option>
                  <?php
                  // Automatically generate exact heights from 4'5" to 6'8"
                  for ($feet = 4; $feet <= 6; $feet++) {
                      for ($inches = 0; $inches <= 11; $inches++) {
                          // Start at 4'5" and end at 6'8"
                          if ($feet == 4 && $inches < 5) continue; 
                          if ($feet == 6 && $inches > 8) continue;

                          // Calculate exact CM for the backend
                          $cm = round(($feet * 30.48) + ($inches * 2.54));
                          
                          // Format the visible label
                          $label = "{$feet}' {$inches}\"  ({$cm} সেমি)";
                          $selected = (($form_old['height_cm']??'') == $cm) ? 'selected' : '';

                          echo "<option value=\"{$cm}\" {$selected}>{$label}</option>\n";
                      }
                  }
                  ?>
                </select>
                <div class="form-error-text" id="err_height">সঠিক উচ্চতা বেছে নিন।</div>
              </div>
              <div class="form-group">
                <label class="form-label" for="weight_kg">ওজন (কেজি)</label>
                <input class="form-input" type="number" id="weight_kg" name="weight_kg"
                       placeholder="যেমন: 55 (ঐচ্ছিক)"
                       min="30" max="150"
                       value="<?= htmlspecialchars($form_old['weight_kg'] ?? '') ?>">
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" for="address">বর্তমান ঠিকানা <span>*</span></label>
                <input class="form-input" type="text" id="address" name="address"
                      placeholder="যেমন: জেলা, উপজেলা, এবং বিস্তারিত..."
                      value="<?= htmlspecialchars($form_old['address'] ?? '') ?>"
                      required>
                <div class="form-error-text" id="err_address">আপনার সম্পূর্ণ ঠিকানা লিখুন।</div>
              </div>
              <div class="form-group">
                <label class="form-label" for="skin_tone">স্কিন টোন</label>
                <select class="form-select" id="skin_tone" name="skin_tone">
                  <option value="">বেছে নিন (ঐচ্ছিক)</option>
                  <option value="fair"     <?= ($form_old['skin_tone']??'')==='fair'    ?'selected':'' ?>>ফর্সা</option>
                  <option value="wheatish" <?= ($form_old['skin_tone']??'')==='wheatish'?'selected':'' ?>>গম-বর্ণ</option>
                  <option value="dusky"    <?= ($form_old['skin_tone']??'')==='dusky'   ?'selected':'' ?>>শ্যামলা</option>
                  <option value="dark"     <?= ($form_old['skin_tone']??'')==='dark'    ?'selected':'' ?>>কালো</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="experience">পূর্ব অভিজ্ঞতা <span>*</span></label>
              <select class="form-select" id="experience" name="experience">
                <option value="none"         <?= ($form_old['experience']??'none')==='none'        ?'selected':'' ?>>কোনো অভিজ্ঞতা নেই</option>
                <option value="some"         <?= ($form_old['experience']??'')==='some'            ?'selected':'' ?>>কিছুটা অভিজ্ঞতা আছে</option>
                <option value="professional" <?= ($form_old['experience']??'')==='professional'    ?'selected':'' ?>>পেশাদার অভিজ্ঞতা আছে</option>
              </select>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" for="fb_profile">ফেসবুক প্রোফাইল লিংক</label>
                <input class="form-input" type="url" id="fb_profile" name="fb_profile"
                       placeholder="facebook.com/yourname"
                       value="<?= htmlspecialchars($form_old['fb_profile'] ?? '') ?>">
              </div>
              <div class="form-group">
                <label class="form-label" for="how_heard">কীভাবে জানলেন?</label>
                <select class="form-select" id="how_heard" name="how_heard">
                  <option value="facebook"  <?= ($form_old['how_heard']??'facebook')==='facebook' ?'selected':'' ?>>ফেসবুক</option>
                  <option value="instagram" <?= ($form_old['how_heard']??'')==='instagram'        ?'selected':'' ?>>ইনস্টাগ্রাম</option>
                  <option value="friend"    <?= ($form_old['how_heard']??'')==='friend'           ?'selected':'' ?>>বন্ধু / পরিচিত</option>
                  <option value="poster"    <?= ($form_old['how_heard']??'')==='poster'           ?'selected':'' ?>>পোস্টার / ব্যানার</option>
                  <option value="other"     <?= ($form_old['how_heard']??'')==='other'            ?'selected':'' ?>>অন্যান্য</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">আপনার ছবি আপলোড করুন</label>
              <div class="upload-zone" id="uploadZone">
                <input type="file" id="photo" name="photo" accept="image/jpeg,image/png,image/webp">
                <div class="upload-icon">📸</div>
                <div class="upload-text">
                  <strong>ক্লিক করুন</strong> বা টেনে আনুন<br>
                  JPG, PNG, WEBP — সর্বোচ্চ ৫ MB
                </div>
                <div class="upload-preview" id="uploadPreview">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><polyline points="20 6 9 17 4 12"/></svg>
                  <span id="uploadFileName"></span>
                </div>
              </div>
            </div>

            <button type="submit" class="form-submit" id="submitBtn">
              রেজিস্ট্রেশন সম্পন্ন করুন →
            </button>

            <p style="text-align:center;font-size:0.85rem;color:var(--text-muted);margin-top:16px;">
              আপনার তথ্য সম্পূর্ণ নিরাপদ এবং তৃতীয় পক্ষের সাথে শেয়ার করা হবে না।
            </p>
          </form>
        </div>
      </div>

    </div>
  </div>
</section>
<?php endif; ?>

<section class="section" id="faq">
  <div class="container">
    <div style="text-align:center; margin-bottom:48px;" class="reveal">
      <div class="section-label" style="justify-content:center;">সাধারণ প্রশ্ন</div>
      <h2 class="section-title">আপনার মনে প্রশ্ন আছে?</h2>
    </div>
    <div class="faq-list reveal" id="faqList">
      <?php foreach ($faqs as $i => $faq): ?>
      <div class="faq-item" data-faq="<?= $i ?>">
        <button class="faq-q" aria-expanded="false">
          <span><?= htmlspecialchars($faq['q']) ?></span>
          <div class="faq-icon">+</div>
        </button>
        <div class="faq-a" role="region">
          <div class="faq-a-inner"><?= htmlspecialchars($faq['a']) ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<footer class="footer">
  <div class="footer-logo">ঢাকা মডেল এজেন্সি</div>
  <div class="footer-contact">
    <?php if ($contact_phone): ?><a href="tel:<?= htmlspecialchars($contact_phone) ?>"><?= htmlspecialchars($contact_phone) ?></a>  ·  <?php endif; ?>
    <?php if ($contact_email): ?><a href="mailto:<?= htmlspecialchars($contact_email) ?>"><?= htmlspecialchars($contact_email) ?></a><?php endif; ?>
  </div>
  <div class="footer-copy">© <?= date('Y') ?> ঢাকা মডেল এজেন্সি। সর্বস্বত্ব সংরক্ষিত।</div>
</footer>

<?php if ($is_active): ?>
<div class="sticky-bar" id="stickyBar">
  <div>
    <div class="sticky-price-label">কোর্স ফি</div>
    <div class="sticky-price">৳৫,০০০</div>
  </div>
  <button class="sticky-cta" onclick="document.getElementById('register').scrollIntoView({behavior:'smooth'})">
    রেজিস্ট্রেশন করুন →
  </button>
</div>
<?php endif; ?>

<script>
// ── Navbar scroll effect ─────────────────────────────────────
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });

// ── Scroll reveal ─────────────────────────────────────────────
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// ── YouTube Facade ────────────────────────────────────────────
const ytFacade = document.getElementById('ytFacade');
const ytIframe = document.getElementById('ytIframe');
if (ytFacade) {
  ytFacade.addEventListener('click', () => {
    const id = ytFacade.dataset.ytid;
    ytFacade.style.display = 'none';
    ytIframe.style.display = 'block';
    ytIframe.innerHTML = `<iframe src="https://www.youtube.com/embed/${id}?autoplay=1&rel=0"
      allow="autoplay; encrypted-media; fullscreen" allowfullscreen loading="lazy"></iframe>`;

    <?php if (!empty($pixel_id)): ?>
    if (typeof fbq !== 'undefined') fbq('trackCustom', 'VideoPlay', { content_name: 'DMA Grooming Promo' });
    <?php endif; ?>
  });
}

// ── FAQ Accordion ─────────────────────────────────────────────
document.querySelectorAll('.faq-q').forEach(btn => {
  btn.addEventListener('click', () => {
    const item    = btn.parentElement;
    const isOpen  = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(el => el.classList.remove('open'));
    if (!isOpen) item.classList.add('open');
    btn.setAttribute('aria-expanded', String(!isOpen));
  });
});

// ── Sticky bar visibility (hide near form) ────────────────────
const stickyBar = document.getElementById('stickyBar');
const formSection = document.getElementById('register');

if (stickyBar && formSection) {
  let stickyVisible = false;

  const updateSticky = () => {
    const scrollY = window.scrollY;
    const heroH   = document.getElementById('hero').offsetHeight;
    const formRect = formSection.getBoundingClientRect();
    const nearForm = formRect.top < window.innerHeight && formRect.bottom > 0;

    if (scrollY > heroH * 0.6 && !nearForm) {
      stickyBar.classList.add('visible');
      stickyBar.classList.remove('hidden-near-form');
    } else {
      stickyBar.classList.remove('visible');
    }
  };

  window.addEventListener('scroll', updateSticky, { passive: true });
  updateSticky();
}

// ── Photo upload UX ───────────────────────────────────────────
const photoInput   = document.getElementById('photo');
const uploadZone   = document.getElementById('uploadZone');
const uploadPreview = document.getElementById('uploadPreview');
const uploadFileName = document.getElementById('uploadFileName');

if (photoInput) {
  photoInput.addEventListener('change', () => {
    const file = photoInput.files[0];
    if (file) {
      uploadFileName.textContent = file.name;
      uploadPreview.classList.add('show');
    }
  });

  ['dragover','dragenter'].forEach(ev => {
    uploadZone.addEventListener(ev, e => { e.preventDefault(); uploadZone.style.borderColor = 'var(--primary)'; });
  });
  ['dragleave','drop'].forEach(ev => {
    uploadZone.addEventListener(ev, () => uploadZone.style.borderColor = '');
  });
}

// ── Form inline validation ────────────────────────────────────
const regForm = document.getElementById('regForm');
if (regForm) {
  const rules = {
    full_name: v => v.trim().length >= 3,
    phone:     v => /^(\+8801|01)[3-9]\d{8}$/.test(v.replace(/\s/g,'')),
    dob:       v => {
      if (!v) return false;
      const age = Math.floor((new Date() - new Date(v)) / (365.25*24*3600*1000));
      return age >= 16 && age <= 35;
    },
    gender:    v => ['male','female','other'].includes(v),
    height_cm: v => v !== '',
    address:   v => v.trim().length >= 5,
  };

  const validateField = (name, value) => {
    const errEl = document.getElementById('err_' + name);
    const input = document.getElementById(name);
    if (!rules[name] || !errEl || !input) return true;
    const valid = rules[name](value);
    input.classList.toggle('invalid', !valid);
    errEl.classList.toggle('show', !valid);
    return valid;
  };

  // Live validation on blur
  Object.keys(rules).forEach(name => {
    const el = document.getElementById(name);
    if (el) {
      el.addEventListener('blur', () => validateField(name, el.value));
      el.addEventListener('input', () => {
        if (el.classList.contains('invalid')) validateField(name, el.value);
      });
    }
  });

  // Pre-submit validation
  regForm.addEventListener('submit', e => {
    let allValid = true;
    Object.keys(rules).forEach(name => {
      const el = document.getElementById(name);
      if (el && !validateField(name, el.value)) allValid = false;
    });
    if (!allValid) {
      e.preventDefault();
      const firstErr = regForm.querySelector('.form-input.invalid, .form-select.invalid');
      if (firstErr) firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    // Fire pixel ViewContent on submit attempt
    <?php if (!empty($pixel_id)): ?>
    if (typeof fbq !== 'undefined') fbq('track', 'InitiateCheckout', { content_name: 'DMA Registration' });
    <?php endif; ?>
    document.getElementById('submitBtn').disabled = true;
    document.getElementById('submitBtn').textContent = 'জমা দেওয়া হচ্ছে…';
  });
}
</script>

</body>
</html>

<?php
// ── SVG Icon Helper (inline, no external lib) ──────────────
function get_curriculum_icon(string $name): string {
  $icons = [
    'walk' => '<svg viewBox="0 0 24 24"><path d="M13 4a1 1 0 1 0 2 0 1 1 0 0 0-2 0"/><path d="M7.5 17.5L9 14l3 2 2-5.5"/><path d="M17 8.5l-3.5.5-1 3 3 2-1 5"/></svg>',
    'camera' => '<svg viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
    'face' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>',
    'body' => '<svg viewBox="0 0 24 24"><path d="M18 3a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3"/><path d="M13 8.5c-2 0-4.5 1.5-5 4l-1 4.5 3 .5.5-3.5"/><path d="M16.5 8.5l1.5 4-3.5 2-.5 5h-2l.5-5-2.5-1.5"/></svg>',
    'style' => '<svg viewBox="0 0 24 24"><path d="M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44z"/><path d="M10.59 15.41a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z"/></svg>',
    'network' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M12 7v4M5 17l5-4M19 17l-5-4"/></svg>',
  ];
  return $icons[$name] ?? $icons['camera'];
}
?>