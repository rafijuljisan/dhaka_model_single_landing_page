<?php
// ============================================================
// submit.php  — Public Registration Form Handler
// ============================================================

require_once __DIR__ . '/../core/includes/functions.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    redirect('/index.php');
}

// CSRF check
$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    http_response_code(403);
    redirect('/index.php?error=invalid_token');
}

// Check campaign is active
if (get_setting('campaign_active', '1') !== '1') {
    redirect('/index.php?error=campaign_closed');
}

// Check registration cap
$db    = db();
$count = $db->query("SELECT COUNT(*) AS c FROM registrations")->fetch_assoc()['c'];
$max   = (int) get_setting('max_registrations', '500');
if ($count >= $max) {
    redirect('/index.php?error=quota_full');
}

// Validate + sanitize
$result = validate_registration($_POST);

if (!empty($result['errors'])) {
    // Store errors in session and redirect back
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['form_errors'] = $result['errors'];
    $_SESSION['form_old']    = $_POST;  // repopulate fields
    redirect('/index.php?error=validation');
}

// Save to DB
$save = save_registration($result['data']);

if (!$save['success']) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['form_errors'] = [$save['error']];
    $_SESSION['form_old']    = $_POST;
    redirect('/index.php?error=save_failed');
}

// Send email (non-blocking — failure is acceptable)
if (!empty($result['data']['email'])) {
    send_notification_email($save['reg_code'], $result['data']['full_name'], $result['data']['email']);
}

// Clear any old session data
if (session_status() === PHP_SESSION_NONE) session_start();
unset($_SESSION['form_errors'], $_SESSION['form_old']);

// Pass reg code to thank-you page via session (never in URL)
$_SESSION['reg_code']  = $save['reg_code'];
$_SESSION['applicant'] = $result['data']['full_name'];

redirect('/thank-you.php');
